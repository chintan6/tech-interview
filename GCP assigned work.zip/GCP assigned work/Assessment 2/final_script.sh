#!/bin/bash
#
# To get instance_name from user
echo "Enter the instance name: "
read instance_input_name
echo "User entered : $instance_input_name"
#
# To get instance m
echo "**** Instance data ****"
gcloud compute instances describe $instance_input_name --format=json > instance_data
#
# To get instance custom metadata
echo "**** Instance custom data ****"
gcloud compute instances describe $instance_input_name --format=json --flatten="metadata[]> instance_metadata
#
# To get NIA and firewall metadata
echo "**** Network Interface  and firewall metadata ****"
gcloud compute instances network-interfaces get-effective-firewalls $instance_input_name --format=json > NIA_data
#
# To get OS inventory metadata
echo "**** OS inventory metadata ****"
gcloud compute instances os-inventory describe $instance_input_name --format=json > OS_inventory_data
#
# To get GCE disk metadata
echo "**** GCE disk attached metadata ****"
gcloud compute disks list --filter=$instance_input_name --format=json > disk_data
#
echo "**** End of GCE metadata script****"
